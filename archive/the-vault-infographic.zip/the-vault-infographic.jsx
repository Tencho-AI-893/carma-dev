import { Shield, WifiOff, AlertTriangle, Lock, Server, Zap, Heart, Scale, Moon, Package, ChevronRight, Star, ArrowRight } from "lucide-react";

const COLORS = {
  navy: "#0A1628",
  navyLight: "#112240",
  navyMid: "#1B3461",
  accent: "#F97316",
  emerald: "#10B981",
  gold: "#F59E0B",
  text: "#E2E8F0",
  textMuted: "#94A3B8",
  border: "rgba(255,255,255,0.08)",
};

const glassStyle = {
  background: "rgba(17, 34, 64, 0.7)",
  backdropFilter: "blur(12px)",
  border: "1px solid rgba(255,255,255,0.08)",
  borderRadius: "16px",
};

export default function TheVaultInfographic() {
  return (
    <div
      style={{
        background: `radial-gradient(ellipse at 20% 20%, #1B3461 0%, #0A1628 50%, #050D1A 100%)`,
        minHeight: "100vh",
        fontFamily: "'Georgia', 'Times New Roman', serif",
        color: COLORS.text,
        padding: "24px 16px",
        boxSizing: "border-box",
      }}
    >
      {/* ── HEADER ── */}
      <div style={{ textAlign: "center", marginBottom: "32px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "12px", marginBottom: "8px" }}>
          <div style={{
            background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.gold})`,
            borderRadius: "12px",
            padding: "10px",
            display: "flex",
          }}>
            <Shield size={28} color="#fff" />
          </div>
          <h1 style={{
            fontSize: "clamp(24px, 5vw, 42px)",
            fontWeight: "900",
            letterSpacing: "0.08em",
            background: `linear-gradient(90deg, #fff 40%, ${COLORS.gold})`,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            margin: 0,
          }}>
            The VAULT
          </h1>
        </div>
        <p style={{ color: COLORS.textMuted, fontSize: "clamp(11px, 2.5vw, 15px)", letterSpacing: "0.3em", textTransform: "uppercase", margin: 0 }}>
          完全オフラインAI構築パッケージ ── あなたの会社だけの要塞
        </p>
        <div style={{ width: "80px", height: "2px", background: `linear-gradient(90deg, transparent, ${COLORS.accent}, transparent)`, margin: "16px auto 0" }} />
      </div>

      {/* ── TOP ROW: 2 blocks ── */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
        gap: "16px",
        marginBottom: "16px",
        maxWidth: "1100px",
        margin: "0 auto 16px",
      }}>
        {/* BLOCK 1: 課題 */}
        <div style={{ ...glassStyle, padding: "24px", position: "relative", overflow: "hidden" }}>
          <div style={{
            position: "absolute", top: 0, right: 0,
            width: "120px", height: "120px",
            background: `radial-gradient(circle, rgba(239,68,68,0.15) 0%, transparent 70%)`,
            pointerEvents: "none",
          }} />
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "20px" }}>
            <div style={{ background: "rgba(239,68,68,0.15)", borderRadius: "8px", padding: "8px" }}>
              <AlertTriangle size={20} color="#EF4444" />
            </div>
            <div>
              <div style={{ fontSize: "10px", color: COLORS.textMuted, letterSpacing: "0.2em", textTransform: "uppercase" }}>Chapter 01</div>
              <div style={{ fontSize: "16px", fontWeight: "700", color: "#fff" }}>時代の壁と課題</div>
            </div>
          </div>

          {/* Timeline */}
          {[
            { icon: "🌐", label: "現状", desc: "ChatGPT等クラウドAIが急速に普及", color: COLORS.emerald },
            { icon: "⚠️", label: "3つの壁", desc: "情報漏洩リスク / 3省2ガイドライン / アカウントBAN", color: COLORS.gold },
            { icon: "🚫", label: "結果", desc: "使いたくても使えない「AI難民」中小企業が続出", color: "#EF4444" },
          ].map((item, i) => (
            <div key={i} style={{ display: "flex", gap: "12px", marginBottom: i < 2 ? "16px" : 0 }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                <div style={{
                  width: "36px", height: "36px", borderRadius: "50%",
                  background: `${item.color}22`,
                  border: `1.5px solid ${item.color}66`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "16px", flexShrink: 0,
                }}>
                  {item.icon}
                </div>
                {i < 2 && <div style={{ width: "1px", flex: 1, background: "rgba(255,255,255,0.1)", marginTop: "4px", minHeight: "16px" }} />}
              </div>
              <div style={{ paddingTop: "6px" }}>
                <div style={{ fontSize: "11px", color: item.color, fontWeight: "700", letterSpacing: "0.1em", marginBottom: "2px" }}>{item.label}</div>
                <div style={{ fontSize: "13px", color: COLORS.textMuted, lineHeight: 1.5 }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>

        {/* BLOCK 2: コア価値 */}
        <div style={{ ...glassStyle, padding: "24px", position: "relative", overflow: "hidden" }}>
          <div style={{
            position: "absolute", top: 0, right: 0,
            width: "150px", height: "150px",
            background: `radial-gradient(circle, rgba(249,115,22,0.12) 0%, transparent 70%)`,
            pointerEvents: "none",
          }} />
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "20px" }}>
            <div style={{ background: `rgba(249,115,22,0.15)`, borderRadius: "8px", padding: "8px" }}>
              <Lock size={20} color={COLORS.accent} />
            </div>
            <div>
              <div style={{ fontSize: "10px", color: COLORS.textMuted, letterSpacing: "0.2em", textTransform: "uppercase" }}>Chapter 02</div>
              <div style={{ fontSize: "16px", fontWeight: "700", color: "#fff" }}>The VAULTのコア価値</div>
            </div>
          </div>

          {[
            {
              icon: <WifiOff size={18} color={COLORS.accent} />,
              bg: `rgba(249,115,22,0.12)`,
              title: "完全オフライン = 絶対秘密",
              desc: "インターネット遮断。情報は1バイトも外に出ない。",
              badge: "CORE",
              badgeColor: COLORS.accent,
            },
            {
              icon: <Server size={18} color={COLORS.emerald} />,
              bg: `rgba(16,185,129,0.12)`,
              title: "デスク下に自社データセンター",
              desc: "「借りる」から「所有する」へ。固定資産として計上可能。",
              badge: "OWN",
              badgeColor: COLORS.emerald,
            },
            {
              icon: <Zap size={18} color={COLORS.gold} />,
              bg: `rgba(245,158,11,0.12)`,
              title: "サブスク地獄からの解放",
              desc: "リース契約で月額固定化。ランニングコストが読める。",
              badge: "FREE",
              badgeColor: COLORS.gold,
            },
          ].map((item, i) => (
            <div key={i} style={{
              display: "flex", gap: "12px", marginBottom: i < 2 ? "12px" : 0,
              padding: "12px", borderRadius: "10px", background: item.bg,
              border: "1px solid rgba(255,255,255,0.06)",
            }}>
              <div style={{ marginTop: "2px" }}>{item.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "4px" }}>
                  <div style={{ fontSize: "13px", fontWeight: "700", color: "#fff" }}>{item.title}</div>
                  <span style={{
                    fontSize: "9px", fontWeight: "800", letterSpacing: "0.1em",
                    color: item.badgeColor, border: `1px solid ${item.badgeColor}66`,
                    borderRadius: "4px", padding: "2px 6px",
                  }}>{item.badge}</span>
                </div>
                <div style={{ fontSize: "12px", color: COLORS.textMuted, lineHeight: 1.5 }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── CENTER: 3 TARGETS ── */}
      <div style={{ maxWidth: "1100px", margin: "0 auto 16px" }}>
        <div style={{ textAlign: "center", marginBottom: "16px" }}>
          <div style={{
            display: "inline-flex", alignItems: "center", gap: "8px",
            background: "rgba(255,255,255,0.05)", borderRadius: "20px",
            padding: "6px 16px", border: "1px solid rgba(255,255,255,0.08)",
          }}>
            <Star size={14} color={COLORS.gold} />
            <span style={{ fontSize: "11px", letterSpacing: "0.2em", color: COLORS.textMuted, textTransform: "uppercase" }}>Chapter 03 ── 3つのメインターゲット</span>
            <Star size={14} color={COLORS.gold} />
          </div>
        </div>

        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
          gap: "16px",
        }}>
          {[
            {
              num: "01",
              icon: <Heart size={22} color="#F472B6" />,
              iconBg: "rgba(244,114,182,0.15)",
              color: "#F472B6",
              industry: "医療・ヘルスケア",
              pain: "電子カルテの閉域網、厳格な個人情報保護",
              value: "院内LAN完結の「AI秘書」",
              feature: "紹介状を自動要約。診療効率が劇的に向上。",
            },
            {
              num: "02",
              icon: <Scale size={22} color="#818CF8" />,
              iconBg: "rgba(129,140,248,0.15)",
              color: "#818CF8",
              industry: "法務・士業",
              pain: "守秘義務、利益相反チェックの膨大な手間",
              value: "外部0バイト「専用パラリーガル」",
              feature: "過去判例を瞬時検索。業務効率が飛躍的に向上。",
            },
            {
              num: "03",
              icon: <Moon size={22} color={COLORS.emerald} />,
              iconBg: `rgba(16,185,129,0.15)`,
              color: COLORS.emerald,
              industry: "風俗・ナイトレジャー",
              pain: "プラットフォームの検閲、顧客情報の流出リスク",
              value: "検閲解除モデルでBAN回避",
              feature: "最強の「裏方AI」。安心して活用できる唯一の選択肢。",
            },
          ].map((t, i) => (
            <div key={i} style={{
              ...glassStyle,
              padding: "22px",
              position: "relative",
              overflow: "hidden",
            }}>
              {/* Number watermark */}
              <div style={{
                position: "absolute", top: "-8px", right: "12px",
                fontSize: "72px", fontWeight: "900", color: "rgba(255,255,255,0.03)",
                lineHeight: 1, userSelect: "none",
              }}>{t.num}</div>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
                <div style={{ background: t.iconBg, borderRadius: "10px", padding: "8px", display: "flex" }}>
                  {t.icon}
                </div>
                <div style={{ fontSize: "15px", fontWeight: "700", color: "#fff" }}>{t.industry}</div>
              </div>

              <div style={{
                padding: "10px 12px", borderRadius: "8px",
                background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)",
                marginBottom: "12px",
              }}>
                <div style={{ fontSize: "10px", color: "#EF4444", fontWeight: "700", letterSpacing: "0.1em", marginBottom: "4px" }}>✕ PAIN</div>
                <div style={{ fontSize: "12px", color: COLORS.textMuted, lineHeight: 1.5 }}>{t.pain}</div>
              </div>

              <div style={{
                padding: "10px 12px", borderRadius: "8px",
                background: `${t.color}11`, border: `1px solid ${t.color}33`,
                marginBottom: "8px",
              }}>
                <div style={{ fontSize: "10px", color: t.color, fontWeight: "700", letterSpacing: "0.1em", marginBottom: "4px" }}>◎ VALUE</div>
                <div style={{ fontSize: "13px", fontWeight: "700", color: "#fff" }}>{t.value}</div>
              </div>

              <div style={{ fontSize: "12px", color: COLORS.textMuted, lineHeight: 1.5, paddingLeft: "4px" }}>
                <ChevronRight size={12} style={{ display: "inline", marginRight: "4px", color: t.color }} />
                {t.feature}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── BOTTOM: PACKAGES ── */}
      <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "16px" }}>
          <div style={{
            display: "inline-flex", alignItems: "center", gap: "8px",
            background: "rgba(255,255,255,0.05)", borderRadius: "20px",
            padding: "6px 16px", border: "1px solid rgba(255,255,255,0.08)",
          }}>
            <Package size={14} color={COLORS.accent} />
            <span style={{ fontSize: "11px", letterSpacing: "0.2em", color: COLORS.textMuted, textTransform: "uppercase" }}>Chapter 04 ── パッケージ & 価格</span>
          </div>
        </div>

        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
          gap: "16px",
        }}>
          {[
            {
              tier: "梅",
              tierEn: "UME",
              label: "特定業務特化",
              initial: "80万円",
              monthly: "3万円",
              spec: "RTX 5080 + 軽量モデル",
              desc: "まず試したい方へ。特定業務に絞って即導入。",
              color: COLORS.textMuted,
              border: "rgba(148,163,184,0.3)",
              bg: "rgba(148,163,184,0.05)",
              featured: false,
            },
            {
              tier: "竹",
              tierEn: "TAKE",
              label: "業務用標準",
              initial: "180万円",
              monthly: "8万円",
              spec: "RTX 5090 + 70Bモデル + RAG",
              desc: "最もコスパが高く、ほとんどの企業に最適解。",
              color: COLORS.accent,
              border: COLORS.accent,
              bg: `rgba(249,115,22,0.08)`,
              featured: true,
            },
            {
              tier: "松",
              tierEn: "MATSU",
              label: "全社統合",
              initial: "450万円〜",
              monthly: "20万円〜",
              spec: "RTX 5090×2 + 専用チューニング",
              desc: "全社のAI化を一気に実現。エンタープライズ向け。",
              color: COLORS.gold,
              border: `rgba(245,158,11,0.6)`,
              bg: `rgba(245,158,11,0.06)`,
              featured: false,
            },
          ].map((pkg, i) => (
            <div key={i} style={{
              ...glassStyle,
              padding: "22px",
              position: "relative",
              background: pkg.bg,
              border: `1px solid ${pkg.border}`,
              borderRadius: "16px",
              overflow: "hidden",
            }}>
              {pkg.featured && (
                <div style={{
                  position: "absolute", top: "12px", right: "12px",
                  background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.gold})`,
                  borderRadius: "6px", padding: "3px 10px",
                  fontSize: "10px", fontWeight: "800", color: "#fff", letterSpacing: "0.1em",
                }}>
                  一番の売り
                </div>
              )}

              <div style={{ display: "flex", alignItems: "baseline", gap: "8px", marginBottom: "4px" }}>
                <span style={{ fontSize: "28px", color: pkg.color }}>【{pkg.tier}】</span>
                <span style={{ fontSize: "11px", color: pkg.color, letterSpacing: "0.2em" }}>{pkg.tierEn}</span>
              </div>
              <div style={{ fontSize: "13px", color: COLORS.textMuted, marginBottom: "16px" }}>{pkg.label}</div>

              <div style={{ marginBottom: "16px" }}>
                <div style={{ display: "flex", alignItems: "baseline", gap: "6px", marginBottom: "6px" }}>
                  <span style={{ fontSize: "11px", color: COLORS.textMuted }}>初期費用</span>
                  <span style={{ fontSize: "22px", fontWeight: "800", color: "#fff" }}>{pkg.initial}</span>
                </div>
                <div style={{ display: "flex", alignItems: "baseline", gap: "6px" }}>
                  <span style={{ fontSize: "11px", color: COLORS.textMuted }}>月額</span>
                  <span style={{ fontSize: "16px", fontWeight: "700", color: pkg.color }}>{pkg.monthly}</span>
                </div>
              </div>

              <div style={{
                background: "rgba(0,0,0,0.3)", borderRadius: "8px", padding: "8px 12px",
                fontSize: "11px", color: COLORS.textMuted, marginBottom: "12px",
                fontFamily: "monospace", letterSpacing: "0.05em",
              }}>
                ⚙ {pkg.spec}
              </div>

              <div style={{ fontSize: "12px", color: COLORS.textMuted, lineHeight: 1.6 }}>
                <ArrowRight size={12} style={{ display: "inline", marginRight: "4px", color: pkg.color }} />
                {pkg.desc}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{
          textAlign: "center", marginTop: "24px",
          borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: "20px",
        }}>
          <div style={{ fontSize: "11px", color: COLORS.textMuted, letterSpacing: "0.3em", textTransform: "uppercase" }}>
            株式会社 店長 ── SM.Carma presents
          </div>
          <div style={{
            display: "inline-block", marginTop: "8px",
            fontSize: "12px", color: COLORS.textMuted,
            padding: "6px 20px",
            border: `1px solid ${COLORS.accent}44`,
            borderRadius: "20px",
          }}>
            情報は、金庫に眠らせるな。活かせ。ただし、外には出すな。
          </div>
        </div>
      </div>
    </div>
  );
}
